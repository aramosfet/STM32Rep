/*
 * sys_init.h
 *
 *  Created on: Apr 22, 2017
 *      Author: Aravindan
 */

#ifndef SYS_INIT_H_
#define SYS_INIT_H_

void sys_init(void);

#endif /* SYS_INIT_H_ */
