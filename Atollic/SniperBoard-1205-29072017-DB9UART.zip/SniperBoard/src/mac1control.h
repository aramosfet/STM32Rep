/*
 * mac1control.h
 *
 *  Created on: Apr 22, 2017
 *      Author: Aravindan
 */

#ifndef MAC1CONTROL_H_
#define MAC1CONTROL_H_

void mac1_tick(void);
void mac1_init(void);
void mac1_service(void);

#endif /* MAC1CONTROL_H_ */
