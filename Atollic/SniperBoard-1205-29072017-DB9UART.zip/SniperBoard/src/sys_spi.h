/*
 * sys_spi.h
 *
 *  Created on: Mar 20, 2017
 *      Author: Aravindan
 */

#ifndef SYS_SPI_H_
#define SYS_SPI_H_
#include "stm32f10x.h"

void mySPI2_Init(void);
void mySPI1_Init(void);

#endif /* SYS_SPI_H_ */
